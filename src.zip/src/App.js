import "./App.css";
import { useEffect, useState } from "react";
import { cloneDeep } from "lodash";
import JSONCrush from "jsoncrush";
import Component from "./components/Component";

const defaultComponent = {
  id: 1,
  name: "NewComponent",
  variables: [],
};

const defaultNode = {
  id: 1,
  componentId: 1,
  collapsed: false,
  children: [],
};

function App() {
  const [data, _setData] = useState({
    components: [{ ...defaultComponent, name: "App" }],
    tree: [{ ...defaultNode }],
    componentIdIncrementer: 2,
    nodeIdIncrementer: 2,
  });

  const urlParams = new URLSearchParams(window.location.search);
  const urlData = urlParams.get("data");
  useEffect(() => {
    pullStateFromUrl();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [urlData]);

  useEffect(() => {
    window.onpopstate = (e) => {
      pullStateFromUrl();
    };
  });

  const { components, tree, componentIdIncrementer, nodeIdIncrementer } = data;

  /**
   * Update the data state and url state
   * @param {object} newData New data set to be applied
   */
  function setData(newData) {
    _setData(newData);
    const crushedData = JSONCrush.crush(JSON.stringify(newData));
    const url = new URL(window.location);
    url.searchParams.set("data", crushedData);
    window.history.pushState({}, "", url);
  }

  function newComponent() {
    const component = { ...defaultComponent, id: componentIdIncrementer };
    const node = {
      ...defaultNode,
      componentId: component.id,
      id: nodeIdIncrementer,
    };
    setData({
      ...data,
      components: [...components, component],
      tree: [...tree, node],
      componentIdIncrementer: componentIdIncrementer + 1,
      nodeIdIncrementer: nodeIdIncrementer + 1,
    });
  }

  function handleComponentChange(component) {
    const newData = { ...data };
    const index = newData.components.findIndex(
      (item) => item.id === component.id
    );
    newData.components[index] = { ...component };
    setData(newData);
  }

  function handleAddChildToComponent(parentNode) {
    const component = { ...defaultComponent, id: componentIdIncrementer };
    const newTree = cloneDeep(data.tree);
    const node = findNode(parentNode.id, newTree);
    if (node) {
      node.children.push({
        ...defaultNode,
        componentId: component.id,
        id: nodeIdIncrementer,
      });

      setData({
        components: [...components, component],
        tree: newTree,
        componentIdIncrementer: componentIdIncrementer + 1,
        nodeIdIncrementer: nodeIdIncrementer + 1,
      });
    }
  }

  function findNode(id, items) {
    let found;
    for (let i = 0; i < items.length; i++) {
      if (items[i].componentId === id) {
        return items[i];
      } else if (items[i].children.length > 0) {
        found = findNode(id, items[i].children);
        if (found) {
          return found;
        }
      }
    }
    return found;
  }

  function renderNode(node) {
    const component = components.find((item) => item.id === node.componentId);
    const children = node.children.length && node.children.map(renderNode);
    return (
      <Component
        key={node.id}
        component={component}
        onChange={handleComponentChange}
        onAddChildClick={() => handleAddChildToComponent(node)}
      >
        {children.length > 0 && children}
      </Component>
    );
  }

  function pullStateFromUrl() {
    const uncrushed = JSONCrush.uncrush(urlData);
    try {
      const newData = JSON.parse(uncrushed);
      _setData(newData);
    } catch (e) {
      console.log(e);
    }
  }

  return (
    <div className="App">
      <header className="App-header">Header</header>
      {tree.map((node, i) => renderNode(node))}
      <button onClick={newComponent}>New Component</button>
    </div>
  );
}

export default App;
