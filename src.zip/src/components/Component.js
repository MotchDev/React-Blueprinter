import variableCategories from "../config/variableCategories";
import Variable from "./Variable";
import DropdownMenu from "./DropdownMenu";
import DebouncedInput from "./DebouncedInput";

const emptyDefault = {
  type: "string",
  value: "",
};

const Component = ({
  component,
  onChange,
  onToggleCollapsed,
  onAddChildClick,
  children,
}) => {
  const { name, variables } = component;
  function setName(newName) {
    onChange({
      ...component,
      name: newName,
    });
  }

  function handleNewVariableSetClick(variableCategory) {
    const { id, name } = variableCategory;
    const newVariableSet = { id, name, items: [] };

    if (variableCategory.id === "custom") {
      newVariableSet.name = prompt("Enter your variable set name");
      newVariableSet.id = newVariableSet.name.toLowerCase().replace(/ /g, "-");
    }

    const variables = [...component.variables, { ...newVariableSet }].sort(
      sortVariableSet
    );

    onChange({
      ...component,
      variables,
    });
  }

  function onNewVariableClick(variableSetId) {
    const defaultObject = {
      ...emptyDefault,
      ...variableCategories[variableSetId]?.default,
    };
    const items = variables.find(
      (variableSet) => variableSet.id === variableSetId
    )?.items;

    onChange({
      ...component,
      variables: variables.map((variableSet) => {
        if (variableSet.id === variableSetId) {
          return {
            ...variableSet,
            items: [...items, defaultObject],
          };
        }
        return variableSet;
      }),
    });
  }

  function sortVariableSet(setA, setB) {
    const weightA = variableCategories.findIndex((cat) => cat.id === setA.id);
    const weightB = variableCategories.findIndex((cat) => cat.id === setB.id);

    if (weightA === -1) {
      return 1;
    }

    if (weightB === -1) {
      return -1;
    }

    return weightA - weightB;
  }

  function handleVariableChange(variableSetId, index, variable) {
    const items = variables.find(
      (variableSet) => variableSet.id === variableSetId
    )?.items;

    onChange({
      ...component,
      variables: variables.map((variableSet) => {
        if (variableSet.id === variableSetId) {
          return {
            ...variableSet,
            items: items.map((item, i) => {
              if (index === i) {
                return { ...item, ...variable };
              }
              return item;
            }),
          };
        }
        return variableSet;
      }),
    });
  }

  function handleVarableRemove(variableSetId, index) {
    const items = variables.find(
      (variableSet) => variableSet.id === variableSetId
    )?.items;
    onChange({
      ...component,
      variables: variables.map((variableSet) => {
        if (variableSet.id === variableSetId) {
          return {
            ...variableSet,
            items: items.filter((item, i) => i !== index),
          };
        }
        return variableSet;
      }),
    });
  }

  function shouldShowDropdownOption(option) {
    const used = variables.findIndex(
      (variableSet) => variableSet.id === option.id
    );

    return used === -1 || option.id === "custom";
  }

  return (
    <div className="component">
      <div className="flex">
        <div className="name">
          <DebouncedInput
            value={name}
            type="text"
            onChange={(e) => setName(e.target.value)}
          />
        </div>
        <div>
          <DropdownMenu buttonText="+">
            {variableCategories.map(
              (option) =>
                shouldShowDropdownOption(option) && (
                  <button
                    key={option.id}
                    onClick={() => handleNewVariableSetClick(option)}
                  >
                    {option.name}
                  </button>
                )
            )}
          </DropdownMenu>
        </div>
      </div>

      {variables.map((variableSet) => {
        const { id, name, items } = variableSet;

        return (
          <div className="">
            <div className="flex align-center">
              <h3 className="flex-fill">{name}</h3>
              <div>
                <button onClick={() => onNewVariableClick(id)}>+</button>
              </div>
            </div>
            <div>
              {items.map((variable, i) => (
                <Variable
                  type={variable.type}
                  value={variable.value}
                  onChange={(val) => handleVariableChange(id, i, val)}
                  onRemove={() => {
                    handleVarableRemove(id, i);
                  }}
                />
              ))}
            </div>
          </div>
        );
      })}
      <button onClick={onAddChildClick}>Add Child</button>
      {children}
    </div>
  );
};

export default Component;
