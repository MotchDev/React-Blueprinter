import React, { useEffect, useMemo, useState } from "react";
import debounce from "lodash/debounce";

const DebouncedInput = ({ onChange, value, timeout = 300, ...props }) => {
  const [debouncedValue, setValue] = useState(value);
  const handleTextChange = (e) => {
    setValue(e.target.value);
    sendChange(e);
  };

  useEffect(() => {
    setValue(value);
  }, [value]);

  const sendChange = useMemo(
    () => debounce((newValue) => onChange(newValue), timeout),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );
  return (
    <input {...props} onChange={handleTextChange} value={debouncedValue} />
  );
};

export default DebouncedInput;
