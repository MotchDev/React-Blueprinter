import React, { useRef, useState, useEffect } from "react";

const DropdownMenu = ({ children, buttonText }) => {
  const node = useRef();
  const [open, setOpen] = useState();

  const handleClickOutside = (e) => {
    if (!node.current.contains(e.target)) {
      setOpen(false);
    }
  };

  useEffect(() => {
    if (open) {
      document.addEventListener("mousedown", handleClickOutside);
    } else {
      document.removeEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [open]);

  function handleClick(clickCallback) {
    setOpen(false);
    clickCallback();
  }

  return (
    <div ref={node} className="dropdown">
      <button className="dropdown-button" onClick={(e) => setOpen(!open)}>
        {buttonText}
      </button>
      {open && (
        <div className="dropdown-menu">
          {children.map(
            (child) =>
              child &&
              React.cloneElement(child, {
                onClick: () => handleClick(child.props.onClick),
              })
          )}
        </div>
      )}
    </div>
  );
};

export default DropdownMenu;
